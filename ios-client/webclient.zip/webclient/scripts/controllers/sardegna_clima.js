'use strict';

/**
 * @ngdoc function
 * @name bueleApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the bueleApp
 */
angular.module('bueleApp')
  .controller('SardegnaClimaCtrl', function ($scope, $location, $anchorScroll) {
  	
  });
